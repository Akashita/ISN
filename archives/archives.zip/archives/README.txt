
Vous venez de t�l�charger nos archives m�t�orologiques. 

==== UTILISATION ==== 

	Vous trouverez ci-joint vos archives m�t�o, il s'agit d'un fichier CSV �ditable avec n'importe quel tableur (Libre-Office Calc, Excel ... etc), en revanche il est possible 

	que les valeurs ne soient pas reconnues d'office dans le cas o� votre ordinateur reconna�t le point comme une virgule ou la virgule comme un point. Si c'est le cas nous vous 

	invitons � convertir le fichier directement dans le format de votre tableur (.ods / .xls / .xlsx) au moyen d'un service en ligne tel que : https://cloudconvert.com/csv-to-ods par exemple.

==== DYSFONCTIONNENT ==== 

	Il est possible que certaines valeurs soient erron�es � cause de la maintenance de la station m�t�o.

	Dans le cas o� vous avez rep�r� un dysfonctionnement dans notre service d�archive vous pouvez nous contacter par le biais du site gr�ce � la zone commentaire en bas de page. 

	N�h�sitez pas � nous laisser un moyen de vous recontacter tel qu�un num�ro de t�l�phone ou une adresse mail. 

==== LICENCE ====

	Nous tenons � rappeler que ce projet est un projet libre suivant la licence GNU GPL version 3, vous �tes donc autoris� � le redistribuer et � le modifier en tenant compte cette derni�re.

	GNU GPL v3�: https://www.gnu.org/licenses/gpl.html


Bonne continuation avec nos donn�es.